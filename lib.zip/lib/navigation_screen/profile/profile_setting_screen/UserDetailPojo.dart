

class UploadPojo {
  String apiResponseCode;
  String apiResponseMsg;
  UserDetail userDetail;

  UploadPojo({this.apiResponseCode, this.apiResponseMsg, this.userDetail});

  UploadPojo.fromJson(Map<String, dynamic> json) {
    apiResponseCode = json['apiResponseCode'];
    apiResponseMsg = json['apiResponseMsg'];
    userDetail = json['userDetail'] != null
        ? new UserDetail.fromJson(json['userDetail'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['apiResponseCode'] = this.apiResponseCode;
    data['apiResponseMsg'] = this.apiResponseMsg;
    if (this.userDetail != null) {
      data['userDetail'] = this.userDetail.toJson();
    }
    return data;
  }
}

class UserDetail {
  String userID;
  String firstName;
  String lastName;
  String username;
  String email;
  String mobileNumber;
  ProfileImageURL profileImageURL;
  ProfileImageURL userSuspendedTill;
  ProfileImageURL userSuspendedReason;
  ProfileImageURL ipList;
  int isDefault;
  ProfileImageURL lastLoginAt;
  ProfileImageURL lastLoginIP;
  ProfileImageURL deviceInfo;
  String createdAt;
  ProfileImageURL updatedAt;
  String status;

  UserDetail(
      {this.userID,
        this.firstName,
        this.lastName,
        this.username,
        this.email,
        this.mobileNumber,
        this.profileImageURL,
        this.userSuspendedTill,
        this.userSuspendedReason,
        this.ipList,
        this.isDefault,
        this.lastLoginAt,
        this.lastLoginIP,
        this.deviceInfo,
        this.createdAt,
        this.updatedAt,
        this.status});

  UserDetail.fromJson(Map<String, dynamic> json) {
    userID = json['userID'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    username = json['username'];
    email = json['email'];
    mobileNumber = json['mobileNumber'];
    profileImageURL = json['profileImageURL'] != null
        ? new ProfileImageURL.fromJson(json['profileImageURL'])
        : null;
    userSuspendedTill = json['userSuspendedTill'] != null
        ? new ProfileImageURL.fromJson(json['userSuspendedTill'])
        : null;
    userSuspendedReason = json['userSuspendedReason'] != null
        ? new ProfileImageURL.fromJson(json['userSuspendedReason'])
        : null;
    ipList = json['ipList'] != null
        ? new ProfileImageURL.fromJson(json['ipList'])
        : null;
    isDefault = json['isDefault'];
    lastLoginAt = json['lastLoginAt'] != null
        ? new ProfileImageURL.fromJson(json['lastLoginAt'])
        : null;
    lastLoginIP = json['lastLoginIP'] != null
        ? new ProfileImageURL.fromJson(json['lastLoginIP'])
        : null;
    deviceInfo = json['deviceInfo'] != null
        ? new ProfileImageURL.fromJson(json['deviceInfo'])
        : null;
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'] != null
        ? new ProfileImageURL.fromJson(json['updatedAt'])
        : null;
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userID'] = this.userID;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['username'] = this.username;
    data['email'] = this.email;
    data['mobileNumber'] = this.mobileNumber;
    if (this.profileImageURL != null) {
      data['profileImageURL'] = this.profileImageURL.toJson();
    }
    if (this.userSuspendedTill != null) {
      data['userSuspendedTill'] = this.userSuspendedTill.toJson();
    }
    if (this.userSuspendedReason != null) {
      data['userSuspendedReason'] = this.userSuspendedReason.toJson();
    }
    if (this.ipList != null) {
      data['ipList'] = this.ipList.toJson();
    }
    data['isDefault'] = this.isDefault;
    if (this.lastLoginAt != null) {
      data['lastLoginAt'] = this.lastLoginAt.toJson();
    }
    if (this.lastLoginIP != null) {
      data['lastLoginIP'] = this.lastLoginIP.toJson();
    }
    if (this.deviceInfo != null) {
      data['deviceInfo'] = this.deviceInfo.toJson();
    }
    data['createdAt'] = this.createdAt;
    if (this.updatedAt != null) {
      data['updatedAt'] = this.updatedAt.toJson();
    }
    data['status'] = this.status;
    return data;
  }
}

class ProfileImageURL {
  String string;
  bool valid;

  ProfileImageURL({this.string, this.valid});

  ProfileImageURL.fromJson(Map<String, dynamic> json) {
    string = json['String'];
    valid = json['Valid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['String'] = this.string;
    data['Valid'] = this.valid;
    return data;
  }
}