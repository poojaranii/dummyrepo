import 'package:flutter/material.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';

class DemoKyc extends StatefulWidget {
  const DemoKyc({Key key}) : super(key: key);

  @override
  _DemoKycState createState() => _DemoKycState();
}

class _DemoKycState extends State<DemoKyc> {
  @override
  Widget build(BuildContext context) {
    return Container(


    );
  }
}
